 # KindWords.AI (English) - Ready-to-deploy ZIP

This package contains a simple AI Compliment Generator ready for deployment on Vercel.

## Files
- index.html (frontend)
- api/compliment.js (serverless API calling OpenAI)
- about.html, blog.html
- public/privacy.html

## Quick Mobile (Android) Deploy Steps (Vercel + GitHub)
1. On your Android device install the GitHub and Vercel apps or use a mobile browser.
2. Create a new GitHub repo and upload all files (use GitHub website 'Add file' -> 'Upload files').
3. Sign into Vercel and import the GitHub repo.
4. In Vercel project settings set Environment Variable: OPENAI_API_KEY = (your OpenAI API key)
5. Deploy and test. The site URL will be provided by Vercel.

## Notes
- Keep your OPENAI_API_KEY secret. Do not place it in client-side code.
- After creating content (blog posts), apply for Google AdSense and paste ad code into index.html where the placeholder is.
